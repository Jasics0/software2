create
    definer = admin@`%` function cantidad_paga_empleado(miidentificacion int) returns int
BEGIN
DECLARE v_cantidad int;
select SUM(valor) AS cantidad_pagada_empleado into v_cantidad 
from pagos p where empleado = miidentificacion group by p.empleado;
return v_cantidad;
END;

