create
    definer = admin@`%` procedure P3()
BEGIN
DECLARE numero1, numero2 BIGINT;
	set numero1=3;
	set numero2=4;
	if numero1=numero2 then
		select 'Los números son iguales';
	elseif numero1<numero2 then
		select concat('El numero ',numero2,' es mayor');
	else
		select concat('El numero ',numero1,' es mayor');
	end if;
END;

