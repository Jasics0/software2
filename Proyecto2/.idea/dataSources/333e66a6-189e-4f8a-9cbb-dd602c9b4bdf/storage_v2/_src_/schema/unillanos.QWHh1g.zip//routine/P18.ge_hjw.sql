create
    definer = admin@`%` function P18(cod_materia int, cod_programa int, cod_facultad int, ano int,
                                     periodo int) returns int
BEGIN
DECLARE estudiantes INT;
select count(i.estudiante) into estudiantes
from inscripciones i
where i.materia=cod_materia and i.programa=cod_programa
and i.facultad=cod_facultad and i.ano=ano and i.periodo=periodo group by
i.materia;
RETURN estudiantes;
END;

