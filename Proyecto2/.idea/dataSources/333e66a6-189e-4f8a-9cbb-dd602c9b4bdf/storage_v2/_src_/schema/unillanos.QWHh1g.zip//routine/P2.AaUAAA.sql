create
    definer = admin@`%` procedure P2()
BEGIN
DECLARE v_numero, contador,numero BIGINT;
	set v_numero = 2;
	set contador = 0;
	WHILE v_numero <=100 DO
		set numero=0;
	WHILE numero <= sqrt(v_numero) DO
		if v_numero mod numero = 0 then
			set contador = contador + 1;
		end if;
		set numero=numero+1;
	END WHILE;
	if contador = 1 then
		select (v_numero);
		end if;
	set v_numero = v_numero + 1;
	set contador=0;
	END WHILE;
END;

