create
    definer = admin@`%` function P10(cod_elemento int) returns float
BEGIN
DECLARE precio FLOAT;
select avg(d.v_unitario) into precio from DETALLE_ENTRADA d where
d.elemento=cod_elemento;
RETURN precio;
END;

