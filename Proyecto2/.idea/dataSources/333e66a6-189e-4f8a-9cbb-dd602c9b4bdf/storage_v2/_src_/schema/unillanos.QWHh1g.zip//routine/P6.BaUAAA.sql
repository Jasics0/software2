create
    definer = admin@`%` procedure P6()
BEGIN
DECLARE numero BIGINT DEFAULT 0;
WHILE numero < 100 DO
SET numero = numero + 2;
SELECT numero;
END WHILE;
END;

