create
    definer = admin@`%` procedure P5()
BEGIN
DECLARE duracion2 INTEGER;
DECLARE findelbucle INTEGER DEFAULT 0;
DECLARE fecha2 DATE;
DECLARE cursor1 CURSOR FOR SELECT duracion,fecha FROM
ENTREGA_ELEMENTOS ee ;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET findelbucle=1;
OPEN cursor1;
bucle: LOOP
FETCH cursor1 INTO duracion2,fecha2;
IF findelbucle = 1 THEN
LEAVE bucle;
END IF;
update ENTREGA_ELEMENTOS  set fecha_devolucion=date_add(fecha, interval
duracion2 day) where fecha=fecha2;
END LOOP bucle;
CLOSE cursor1;
END;

