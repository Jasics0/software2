create
    definer = admin@`%` procedure P4()
BEGIN
DECLARE v_numero,numero, contador,datos BIGINT;
set v_numero =2;
set contador=0;
set datos=0;
WHILE datos <=1000 DO
set numero=0;
WHILE numero <= sqrt(v_numero) DO
if v_numero mod numero = 0 then
set contador=contador+1;
end if;
set numero=numero+1;
END WHILE;
if contador=1 then
insert into TMP_MISDATOS (id, descripcion) VALUES (v_numero,
concat('El identificador es ',v_numero));
set datos=datos+1;
end if;
set v_numero=v_numero+1;
set contador=0;
END WHILE;
END;

