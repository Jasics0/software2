create
    definer = admin@`%` function P16(codigo int) returns float
BEGIN
DECLARE prom FLOAT;
SELECT round(avg(i.nota),2) INTO prom
FROM inscripciones i
WHERE i.estudiante=codigo AND i.nota>=3;
RETURN prom;
END;

