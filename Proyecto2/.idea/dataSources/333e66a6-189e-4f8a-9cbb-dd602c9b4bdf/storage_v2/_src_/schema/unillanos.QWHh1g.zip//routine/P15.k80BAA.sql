create
    definer = admin@`%` function P15() returns int
BEGIN
DECLARE m,p INT;
SELECT MONTH(NOW()) into m ;
IF m<=6 then
set p=1;
ELSE
set p=2;
END IF;
RETURN p;
END;

