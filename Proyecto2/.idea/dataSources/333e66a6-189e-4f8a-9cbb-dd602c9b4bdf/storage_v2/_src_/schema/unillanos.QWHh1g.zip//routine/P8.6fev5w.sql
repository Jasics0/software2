create
    definer = admin@`%` procedure P8(IN numero1 int, IN numero2 int)
BEGIN
if numero1=numero2 then
select 'Los números son iguales';
elseif numero1<numero2 then
select concat('El numero ',numero2,' es mayor');
else
select concat('El numero ',numero1,' es mayor');
end if;
END;

