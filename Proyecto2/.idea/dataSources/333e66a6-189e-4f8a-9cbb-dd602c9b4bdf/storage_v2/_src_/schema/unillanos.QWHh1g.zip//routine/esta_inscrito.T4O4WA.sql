create
    definer = admin@`%` function esta_inscrito(ano int, periodo int, codigo int) returns varchar(1)
BEGIN
DECLARE total INT;
SELECT COUNT(estudiante) INTO total FROM inscripciones i
WHERE i.estudiante=codigo and i.ano=ano and i.periodo=periodo;
IF total>=1 THEN
RETURN 'S';
ELSE
RETURN 'N';
END IF;
RETURN estudiantes;
END;

