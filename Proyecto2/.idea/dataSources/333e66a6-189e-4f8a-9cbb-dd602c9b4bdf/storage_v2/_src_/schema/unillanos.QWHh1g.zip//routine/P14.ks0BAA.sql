create
    definer = admin@`%` function P14() returns int
BEGIN
DECLARE year_s INT;
SELECT YEAR(NOW()) into year_s ;
RETURN year_s;
END;

