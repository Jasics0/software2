create
    definer = admin@`%` procedure P1()
BEGIN
	DECLARE x  INT default 0 ;
        
	 WHILE x <= 100 DO
      CALL log(concat('myvar is ', x));
       set x=x+2;
    END WHILE;
END;

